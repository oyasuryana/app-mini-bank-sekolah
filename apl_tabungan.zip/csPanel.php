<h1 class="font-weight-bold mt-3">Admin Panel</h1>

<div class="row mt-2">
	<div class="col-md-4 mt-2">
		<div class="card">
			<div class="card-header text-center font-weight-bold">Nasabah</div>
			<div class="card-body text-center bg-success">
				<h3>x Nasabah</h3>
			</div><!--card-body-->
		</div>	<!--card-->
	</div> <!--col-md-4-->
	
	
	<div class="col-md-4 mt-2">
		<div class="card">
			<div class="card-header text-center font-weight-bold">Simpanan</div>
			<div class="card-body text-center bg-warning">
				<h3>x Nasabah</h3>
			</div><!--card-body-->
		</div>	<!--card-->
	</div> <!--col-md-4-->
	
	<div class="col-md-4 mt-2">
		<div class="card">
			<div class="card-header text-center font-weight-bold">Nasabah Non Aktif</div>
			<div class="card-body text-center bg-danger">
				<h3>x Nasabah</h3>
			</div><!--card-body-->
		</div>	<!--card-->
	</div> <!--col-md-4-->

</div> <!--row-->



