<?php
// memulai session
session_start();

// membuang session
session_destroy();

// mengarahkan ke index.php
header('location:index.php');
?>
